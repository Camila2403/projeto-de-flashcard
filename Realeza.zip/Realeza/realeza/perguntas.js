criaCartao(
    'Realeza Inglesa',
    'Quem era a ultima Rainha?',
    'Elizabeth II'
)

criaCartao(
    'Realeza antiga brasileira',
    'Quem foi o primeiro imperador?',
    'Dom Pedro I'
)

criaCartao(
    'Realeza da Espanha',
    'Quem é a atual rainha da Espanha',
    'Letizia Ortiz'
)

criaCartao(
    'Realeza global',
    'Quantas monarquias existem atualmente?',
    '44 países que adotam o sistema monárquico'
)